
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Cargas</title>

    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="meu-container">

        <div class="header">
            <h2>Log Count</h2>
            <h5>Sua carga nossa contagem</h5>
        </div>

        <div class="botoes">

            <a href="entrada" class="btn btn-entrada">
                Registrar motorista
            </a>

            <a href="saida" class="btn btn-saida">
                Registrar carga
            </a>

            <a href="https://www.nfe.fazenda.gov.br/"
               class="btn btn-importar-xml"
               target="_blank"
               rel="noopener noreferrer">
                📄 Consultar nfe
            </a>

        </div>

        <div class="motorista">

            <div>
                <strong>ID:</strong> 001
            </div>

            <div>
                <strong>Nome:</strong> João da Silva
            </div>

            <div>
                <strong>CPF:</strong> 000.000.000-00
            </div>

            <div>
                <strong>Caminhão:</strong> Volvo FH
            </div>

            <div>
                <strong>Placa:</strong> ABC-1234
            </div>

            <div>
                <strong>Carreta:</strong> SR/Randon
            </div>

            <div class="acoes-motorista">

                <a href="editarmotorista" class="btn-editar">
                    ✏️ Editar
                </a>

                <a href="papeleta/" class="btn-papeleta">
                    📄 Papeleta
                </a>

            </div>

        </div>

    </div>

</body>
</html>


</body>
</html>
