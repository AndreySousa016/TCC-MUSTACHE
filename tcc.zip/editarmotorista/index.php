<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Cargas</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<div id="meu-container">
 <a class="btnvoltar" href="../">← Voltar</a>
    <div class="header">
        <h2>Editar Motorista</h2>
    </div>


    <!-- ===========================
         FORMULÁRIO
    ============================ -->

    <div class="form-carga">

        <h3>Informações do Motorista</h3>

        <form id="form-editar-motorista">

            <!-- ===========================
                 DADOS DO MOTORISTA
            ============================ -->

            <fieldset>

                <legend>Dados do Motorista</legend>

                <div class="campo">
                    <label for="edit-id">ID</label>
                    <input
                        type="text"
                        id="edit-id"
                        name="id"
                        value="001"
                        readonly
                    >
                </div>

                <div class="campo">
                    <label for="edit-nome">Nome</label>
                    <input
                        type="text"
                        id="edit-nome"
                        name="nome"
                        placeholder="Nome completo do motorista"
                    >
                </div>

                <div class="campo">
                    <label for="edit-cpf">CPF</label>
                    <input
                        type="text"
                        id="edit-cpf"
                        name="cpf"
                        placeholder="000.000.000-00"
                    >
                </div>

                <div class="campo">
                    <label for="edit-telefone">Telefone</label>
                    <input
                        type="text"
                        id="edit-telefone"
                        name="telefone"
                        placeholder="(00) 00000-0000"
                    </div>

            </fieldset>


            <!-- ===========================
                 DADOS DO CAMINHÃO
            ============================ -->

            <fieldset>

                <legend>Dados do Caminhão</legend>

                <div class="campo">
                    <label for="edit-caminhao">Caminhão</label>
                    <input
                        type="text"
                        id="edit-caminhao"
                        name="caminhao"
                        placeholder="Modelo do caminhão"
                    >
                </div>

                <div class="campo">
                    <label for="edit-placa">Placa</label>
                    <input
                        type="text"
                        id="edit-placa"
                        name="placa"
                        placeholder="ABC-1234"
                    >
                </div>

                <div class="campo">
                    <label for="edit-modelo">Modelo</label>
                    <input
                        type="text"
                        id="edit-modelo"
                        name="modelo"
                        placeholder="Modelo do veículo"
                    >
                </div>

                <div class="campo">
                    <label for="edit-carreta">Carreta</label>
                    <input
                        type="text"
                        id="edit-carreta"
                        name="carreta"
                        placeholder="Modelo ou identificação da carreta"
                    >
                </div>

            </fieldset>


            <!-- ===========================
                 OBSERVAÇÃO
            ============================ -->

            <fieldset>

                <legend>Observações</legend>

                <div class="campo">

                    <label for="edit-observacao">
                        Observação
                    </label>

                    <textarea
                        id="edit-observacao"
                        name="observacao"
                        rows="4"
                        placeholder="Digite alguma observação..."
                    ></textarea>

                </div>

            </fieldset>


            <!-- ===========================
                 BOTÕES
            ============================ -->

            <div class="botoes">

                <button
                    type="submit"
                    class="btn btn-entrada"
                >
                    Salvar Alterações
                </button>

                <a
                    href="#"
                    class="btn btn-saida"
                >
                    Cancelar
                </a>

            </div>

        </form>

    </div>

</div>
