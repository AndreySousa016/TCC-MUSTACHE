<form action="salvar_carga.php" method="POST" class="form-carga">

    <h3>Registro de Carga</h3>

    <!-- Dados do Motorista -->
    <fieldset>
        <legend>Dados do Motorista</legend>

        <div class="campo">
            <label for="motorista">Nome do Motorista</label>
            <input type="text" id="motorista" name="motorista" required>
        </div>

        <div class="campo">
            <label for="cpf">CPF</label>
            <input type="text" id="cpf" name="cpf" maxlength="14" placeholder="000.000.000-00" required>
        </div>

        <div class="campo">
            <label for="rg">RG</label>
            <input type="text" id="rg" name="rg">
        </div>

        <div class="campo">
            <label for="cnh">CNH</label>
            <input type="text" id="cnh" name="cnh" required>
        </div>

        <div class="campo">
            <label for="telefone">Telefone</label>
            <input type="tel" id="telefone" name="telefone" placeholder="(00) 00000-0000">
        </div>
    </fieldset>
