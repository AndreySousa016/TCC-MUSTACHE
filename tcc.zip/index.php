<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Cargas</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="meu-container">

        <div class="header">
            <h2>A'doro - Gestão de Cargas</h2>
        </div>

        <div class="botoes">
            <a href="entrada" class="btn btn-entrada">Registrar motorista</a>
            <a href="saida" class="btn btn-saida">Registrar carga</a>
        </div>

   
  
   

</form>

</body>
</html>
