<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Cargas</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="meu-container">

        <div class="header">
            <h2>A'doro - Gestão de Cargas</h2>
        </div>

        <div class="botoes">
            <a href="entrada" class="btn btn-entrada">Registrar motorista</a>
            <a href="saida" class="btn btn-saida">Registrar carga</a>
            
        </div>
<div class="motorista">
    

    <div>
        <strong>ID:</strong> 001
    </div>

    <div>
        <strong>Nome:</strong> João da Silva
    </div>

    <div>
        <strong>CPF:</strong> 000.000.000-00
    </div>

    <div>
        <strong>Caminhão:</strong> Volvo FH
    </div>

    <div>
        <strong>Placa:</strong> ABC-1234
    </div>

    <div>
        <strong>Carreta:</strong> SR/Randon
    </div>

    <button class="btn-editar" type="button">
       <a href="editarmotorista" class="btn-editar">Editar</a>
    </button>

</div>

  
   

</form>

</body>
</html>
