<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Gestão de Cargas</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <div id="meu-container">

        <div class="header">
            <h2>A'doro - Gestão de Cargas</h2>
        </div>

        <div class="botoes">
            <a href="entrada" class="btn btn-entrada">Registrar motorista</a>
            <a href="saida" class="btn btn-saida">Registrar carga</a>
        </div>

    </div>

</body>
</html>
<form action="salvar_carga.php" method="POST" class="form-carga">

    <h3>Registro de Carga</h3>

    <!-- Dados do Motorista -->
    <fieldset>
        <legend>Dados do Motorista</legend>

        <div class="campo">
            <label for="motorista">Nome do Motorista</label>
            <input type="text" id="motorista" name="motorista" required>
        </div>

        <div class="campo">
            <label for="cpf">CPF</label>
            <input type="text" id="cpf" name="cpf" maxlength="14" placeholder="000.000.000-00" required>
        </div>

        <div class="campo">
            <label for="rg">RG</label>
            <input type="text" id="rg" name="rg">
        </div>

        <div class="campo">
            <label for="cnh">CNH</label>
            <input type="text" id="cnh" name="cnh" required>
        </div>

        <div class="campo">
            <label for="telefone">Telefone</label>
            <input type="tel" id="telefone" name="telefone" placeholder="(00) 00000-0000">
        </div>
    </fieldset>

    <!-- Dados do Veículo -->
    <fieldset>
        <legend>Veículo</legend>

        <div class="campo">
            <label for="placaCavalo">Placa do Cavalo</label>
            <input type="text" id="placaCavalo" name="placaCavalo" required>
        </div>

        <div class="campo">
            <label for="placaCarreta">Placa da Carreta</label>
            <input type="text" id="placaCarreta" name="placaCarreta">
        </div>

        <div class="campo">
            <label for="transportadora">Transportadora</label>
            <input type="text" id="transportadora" name="transportadora">
        </div>
    </fieldset>

    <!-- Dados da Carga -->
    <fieldset>
        <legend>Carga</legend>

        <div class="campo">
            <label for="tipoCarga">Tipo de Carga</label>
            <input type="text" id="tipoCarga" name="tipoCarga" required>
        </div>

        <div class="campo">
            <label for="notaFiscal">Nota Fiscal</label>
            <input type="text" id="notaFiscal" name="notaFiscal">
        </div>

        <div class="campo">
            <label for="origem">Origem</label>
            <input type="text" id="origem" name="origem">
        </div>

        <div class="campo">
            <label for="destino">Destino</label>
            <input type="text" id="destino" name="destino">
        </div>

        <div class="campo">
            <label for="peso">Peso (kg)</label>
            <input type="number" id="peso" name="peso" step="0.01">
        </div>

        <div class="campo">
            <label for="observacao">Observações</label>
            <textarea id="observacao" name="observacao"></textarea>
        </div>
    </fieldset>

    <button type="submit">Registrar Carga</button>

</form>