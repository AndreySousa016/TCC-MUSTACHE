<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Papeleta de Carga</title>

    <link rel="stylesheet" href="../css/style.css">
</head>

<body>

    <main class="folha">

        <!-- CABEÇALHO -->

        <header class="cabecalho">

            <div class="logo">
                <div class="icone">🚛</div>

                <div>
                    <h1>A'DORO</h1>
                    <span>GESTÃO DE CARGAS</span>
                </div>
            </div>

            <div class="documento">
                <strong>PAPELETA DE CARGA</strong>

                <span>Nº 000001</span>

                <span>16/09/2026</span>
            </div>

        </header>


        <!-- STATUS -->

        <section class="status-area">

            <div>
                <span class="titulo-status">STATUS DA OPERAÇÃO</span>

                <strong class="status">CARGA REGISTRADA</strong>
            </div>

            <div class="codigo">
                OPERAÇÃO #000001
            </div>

        </section>


        <!-- MOTORISTA -->

        <section class="bloco">

            <div class="titulo-bloco">
                <span>01</span>
                DADOS DO MOTORISTA
            </div>

            <div class="grid">

                <div class="campo grande">
                    <label>Nome completo</label>
                    <strong>João da Silva</strong>
                </div>

                <div class="campo">
                    <label>CPF</label>
                    <strong>000.000.000-00</strong>
                </div>

                <div class="campo">
                    <label>CNH</label>
                    <strong>00000000000</strong>
                </div>

                <div class="campo">
                    <label>Telefone</label>
                    <strong>(16) 99999-9999</strong>
                </div>

            </div>

        </section>


        <!-- VEÍCULO -->

        <section class="bloco">

            <div class="titulo-bloco">
                <span>02</span>
                DADOS DO VEÍCULO
            </div>

            <div class="grid">

                <div class="campo">
                    <label>Caminhão</label>
                    <strong>Volvo FH</strong>
                </div>

                <div class="campo">
                    <label>Placa do cavalo</label>
                    <strong>ABC-1234</strong>
                </div>

                <div class="campo">
                    <label>Carreta</label>
                    <strong>SR/Randon</strong>
                </div>

                <div class="campo">
                    <label>Placa da carreta</label>
                    <strong>XYZ-5678</strong>
                </div>

                <div class="campo grande">
                    <label>Transportadora</label>
                    <strong>A'Doro Transportes</strong>
                </div>

            </div>

        </section>


        <!-- CARGA -->

        <section class="bloco">

            <div class="titulo-bloco">
                <span>03</span>
                DADOS DA CARGA
            </div>

            <div class="grid">

                <div class="campo grande">
                    <label>Tipo de carga</label>
                    <strong>Grãos / Soja</strong>
                </div>

                <div class="campo">
                    <label>Nota fiscal</label>
                    <strong>000123</strong>
                </div>

                <div class="campo destaque">
                    <label>Peso da carga</label>
                    <strong>28.500 kg</strong>
                </div>

                <div class="campo">
                    <label>Origem</label>
                    <strong>São Carlos - SP</strong>
                </div>

                <div class="campo">
                    <label>Destino</label>
                    <strong>Campinas - SP</strong>
                </div>

            </div>

        </section>


        <!-- CONFERÊNCIA -->

        <section class="bloco">

            <div class="titulo-bloco">
                <span>04</span>
                CONFERÊNCIA DA CARGA
            </div>

            <div class="checklist">

                <div>
                    <span class="check">✓</span>
                    Motorista identificado
                </div>

                <div>
                    <span class="check">✓</span>
                    Veículo conferido
                </div>

                <div>
                    <span class="check">✓</span>
                    Documentação conferida
                </div>

                <div>
                    <span class="check">✓</span>
                    Peso registrado
                </div>

            </div>

        </section>


        <!-- OBSERVAÇÃO -->

        <section class="observacao">

            <label>OBSERVAÇÕES</label>

            <p>
                Carga conferida e registrada no sistema.
            </p>

        </section>


        <!-- ASSINATURAS -->

        <section class="assinaturas">

            <div class="assinatura">
                <div></div>
                <span>Responsável pela conferência</span>
            </div>

            <div class="assinatura">
                <div></div>
                <span>Motorista</span>
            </div>

        </section>


        <!-- RODAPÉ -->

        <footer>

            <div>
                <strong>A'DORO</strong>
                <span>Sistema de Gestão de Cargas</span>
            </div>

            <div class="impressao">
                Documento gerado pelo sistema
            </div>

        </footer>

    </main>


    <!-- BOTÃO VOLTAR -->

    <div class="acoes">

        <a href="../">
            ← Voltar
        </a>
<!-- BOTÕES -->

<div class="acoes">

    <button onclick="window.print()">
        🖨️ Imprimir Papeleta
    </button>

</div>
    </div>

</body>

</html>