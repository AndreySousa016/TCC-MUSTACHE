<fieldset>
        <legend>Veículo</legend>

        <div class="campo">
            <label for="placaCavalo">Placa do Cavalo</label>
            <input type="text" id="placaCavalo" name="placaCavalo" required>
        </div>

        <div class="campo">
            <label for="placaCarreta">Placa da Carreta</label>
            <input type="text" id="placaCarreta" name="placaCarreta">
        </div>

        <div class="campo">
            <label for="transportadora">Transportadora</label>
            <input type="text" id="transportadora" name="transportadora">
        </div>
    </fieldset>

    <!-- Dados da Carga -->
    <fieldset>
        <legend>Carga</legend>

        <div class="campo">
            <label for="tipoCarga">Tipo de Carga</label>
            <input type="text" id="tipoCarga" name="tipoCarga" required>
        </div>

        <div class="campo">
            <label for="notaFiscal">Nota Fiscal</label>
            <input type="text" id="notaFiscal" name="notaFiscal">
        </div>

        <div class="campo">
            <label for="origem">Origem</label>
            <input type="text" id="origem" name="origem">
        </div>

        <div class="campo">
            <label for="destino">Destino</label>
            <input type="text" id="destino" name="destino">
        </div>

        <div class="campo">
            <label for="peso">Peso (kg)</label>
            <input type="number" id="peso" name="peso" step="0.01">
        </div>

        <div class="campo">
            <label for="observacao">Observações</label>
            <textarea id="observacao" name="observacao"></textarea>
        </div>
    </fieldset>

    <button type="submit">Registrar Carga</button>

</form>